define(["scripts/plots/bar", "scripts/plots/pie"], (barGraph, pieChart) => {
  return {
    bar: barGraph,
    pie: pieChart
  }
});
