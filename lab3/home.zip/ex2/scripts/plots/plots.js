define(["./bar", "./pie"], (barGraph, pieChart) => {
  return {
    bar: barGraph,
    pie: pieChart
  }
});
